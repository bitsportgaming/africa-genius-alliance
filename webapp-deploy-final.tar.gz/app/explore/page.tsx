'use client';

import { useState } from 'react';
import { ProtectedRoute } from '@/components/layout/ProtectedRoute';
import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { AGACard, AGAButton, AGAPill, AGAChip } from '@/components/ui';
import { Search, Filter, TrendingUp, Users, MapPin, Grid, List } from 'lucide-react';
import Link from 'next/link';

export default function ExplorePage() {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [selectedCountry, setSelectedCountry] = useState<string | null>(null);
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');

  // Mock data - Replace with real API calls
  const categories = ['All', 'Political', 'Oversight', 'Technical', 'Civic'];
  const countries = ['All Countries', 'Nigeria', 'Ghana', 'Kenya', 'South Africa', 'Egypt'];

  const geniuses = [
    {
      id: 1,
      name: 'Amina Okafor',
      avatar: 'AO',
      position: 'Presidential Candidate',
      category: 'Political',
      country: 'Nigeria',
      votes: 5432,
      followers: 2341,
      rank: 1,
      bio: 'Passionate about healthcare reform and economic development for all Nigerians.',
      verified: true,
    },
    {
      id: 2,
      name: 'Kwame Mensah',
      avatar: 'KM',
      position: 'Minister of Education',
      category: 'Political',
      country: 'Ghana',
      votes: 4891,
      followers: 1987,
      rank: 2,
      bio: 'Education advocate working to provide quality learning opportunities for every child.',
      verified: true,
    },
    {
      id: 3,
      name: 'Zainab Hassan',
      avatar: 'ZH',
      position: 'Healthcare Minister Candidate',
      category: 'Political',
      country: 'Nigeria',
      votes: 4567,
      followers: 1654,
      rank: 3,
      bio: 'Healthcare professional committed to accessible medical services for all.',
      verified: true,
    },
    {
      id: 4,
      name: 'Thabo Ndlovu',
      avatar: 'TN',
      position: 'Education Reform Leader',
      category: 'Civic',
      country: 'South Africa',
      votes: 4234,
      followers: 1432,
      rank: 4,
      bio: 'Transforming education through technology and community engagement.',
      verified: false,
    },
    {
      id: 5,
      name: 'Fatima Diallo',
      avatar: 'FD',
      position: 'Economic Advisor',
      category: 'Technical',
      country: 'Kenya',
      votes: 3998,
      followers: 1298,
      rank: 5,
      bio: 'Building sustainable economic policies for inclusive growth.',
      verified: true,
    },
    {
      id: 6,
      name: 'Samuel Adebayo',
      avatar: 'SA',
      position: 'Infrastructure Oversight',
      category: 'Oversight',
      country: 'Nigeria',
      votes: 3756,
      followers: 1123,
      rank: 6,
      bio: 'Ensuring transparency and accountability in public infrastructure projects.',
      verified: false,
    },
  ];

  return (
    <ProtectedRoute>
      <DashboardLayout>
        <div className="space-y-8">
          {/* Header */}
          <div>
            <h1 className="text-4xl font-black text-text-dark mb-2">
              Explore Geniuses
            </h1>
            <p className="text-lg text-text-gray">
              Discover Africa's brightest minds and support leaders based on merit
            </p>
          </div>

          {/* Search & Filters */}
          <AGACard variant="elevated" padding="lg">
            <div className="flex flex-col lg:flex-row gap-4">
              {/* Search */}
              <div className="flex-1">
                <div className="relative">
                  <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
                  <input
                    type="text"
                    placeholder="Search by name, position, or keyword..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="w-full pl-12 pr-4 py-3 rounded-aga border border-gray-200 focus:border-primary focus:ring-2 focus:ring-primary/20 outline-none transition-all"
                  />
                </div>
              </div>

              {/* View Toggle */}
              <div className="flex items-center gap-2">
                <button
                  onClick={() => setViewMode('grid')}
                  className={`p-3 rounded-lg transition-colors ${
                    viewMode === 'grid'
                      ? 'bg-primary text-white'
                      : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                  }`}
                >
                  <Grid className="w-5 h-5" />
                </button>
                <button
                  onClick={() => setViewMode('list')}
                  className={`p-3 rounded-lg transition-colors ${
                    viewMode === 'list'
                      ? 'bg-primary text-white'
                      : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                  }`}
                >
                  <List className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* Filter Chips */}
            <div className="mt-4 space-y-3">
              {/* Categories */}
              <div>
                <label className="text-sm font-semibold text-text-dark mb-2 block">
                  Category
                </label>
                <div className="flex flex-wrap gap-2">
                  {categories.map((category) => (
                    <AGAChip
                      key={category}
                      selected={selectedCategory === category || (category === 'All' && !selectedCategory)}
                      onClick={() => setSelectedCategory(category === 'All' ? null : category)}
                    >
                      {category}
                    </AGAChip>
                  ))}
                </div>
              </div>

              {/* Countries */}
              <div>
                <label className="text-sm font-semibold text-text-dark mb-2 block">
                  Country
                </label>
                <div className="flex flex-wrap gap-2">
                  {countries.map((country) => (
                    <AGAChip
                      key={country}
                      selected={selectedCountry === country || (country === 'All Countries' && !selectedCountry)}
                      onClick={() => setSelectedCountry(country === 'All Countries' ? null : country)}
                    >
                      {country}
                    </AGAChip>
                  ))}
                </div>
              </div>
            </div>
          </AGACard>

          {/* Results Count */}
          <div className="flex items-center justify-between">
            <p className="text-text-gray">
              Showing <span className="font-semibold text-text-dark">{geniuses.length}</span> geniuses
            </p>
            <select className="px-4 py-2 rounded-lg border border-gray-200 text-text-dark focus:outline-none focus:ring-2 focus:ring-primary/20">
              <option>Most Votes</option>
              <option>Most Followers</option>
              <option>Newest</option>
              <option>Rising Stars</option>
            </select>
          </div>

          {/* Geniuses Grid/List */}
          {viewMode === 'grid' ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {geniuses.map((genius) => (
                <AGACard
                  key={genius.id}
                  variant="elevated"
                  padding="lg"
                  hoverable
                  className="group"
                >
                  {/* Rank Badge */}
                  <div className="absolute top-4 right-4">
                    <AGAPill
                      variant={genius.rank <= 3 ? 'secondary' : 'neutral'}
                      size="sm"
                    >
                      #{genius.rank}
                    </AGAPill>
                  </div>

                  {/* Avatar & Name */}
                  <div className="text-center mb-4">
                    <div className="w-20 h-20 rounded-full bg-gradient-accent flex items-center justify-center text-white font-bold text-2xl mx-auto mb-3 group-hover:scale-110 transition-transform">
                      {genius.avatar}
                    </div>
                    <h3 className="font-bold text-text-dark text-lg flex items-center justify-center gap-1">
                      {genius.name}
                      {genius.verified && (
                        <span className="text-blue-500" title="Verified">
                          ✓
                        </span>
                      )}
                    </h3>
                    <p className="text-sm text-text-gray mb-2">
                      {genius.position}
                    </p>
                    <div className="flex items-center justify-center gap-2">
                      <AGAPill variant="primary" size="sm">
                        {genius.category}
                      </AGAPill>
                      <AGAPill variant="neutral" size="sm">
                        <MapPin className="w-3 h-3 mr-1" />
                        {genius.country}
                      </AGAPill>
                    </div>
                  </div>

                  {/* Bio */}
                  <p className="text-sm text-text-gray text-center mb-4 line-clamp-2">
                    {genius.bio}
                  </p>

                  {/* Stats */}
                  <div className="flex items-center justify-around py-3 border-y border-gray-200 mb-4">
                    <div className="text-center">
                      <div className="flex items-center justify-center gap-1 text-sm font-semibold text-text-dark">
                        <TrendingUp className="w-4 h-4" />
                        {genius.votes.toLocaleString()}
                      </div>
                      <div className="text-xs text-text-gray">Votes</div>
                    </div>
                    <div className="w-px h-8 bg-gray-200" />
                    <div className="text-center">
                      <div className="flex items-center justify-center gap-1 text-sm font-semibold text-text-dark">
                        <Users className="w-4 h-4" />
                        {genius.followers.toLocaleString()}
                      </div>
                      <div className="text-xs text-text-gray">Followers</div>
                    </div>
                  </div>

                  {/* Actions */}
                  <div className="flex gap-2">
                    <AGAButton variant="primary" size="sm" fullWidth>
                      Follow
                    </AGAButton>
                    <Link href={`/genius/${genius.id}`}>
                      <AGAButton variant="outline" size="sm">
                        View
                      </AGAButton>
                    </Link>
                  </div>
                </AGACard>
              ))}
            </div>
          ) : (
            <div className="space-y-4">
              {geniuses.map((genius) => (
                <AGACard
                  key={genius.id}
                  variant="elevated"
                  padding="lg"
                  hoverable
                >
                  <div className="flex items-start gap-6">
                    {/* Avatar */}
                    <div className="w-16 h-16 rounded-full bg-gradient-accent flex items-center justify-center text-white font-bold text-xl flex-shrink-0">
                      {genius.avatar}
                    </div>

                    {/* Content */}
                    <div className="flex-1">
                      <div className="flex items-start justify-between mb-2">
                        <div>
                          <h3 className="font-bold text-text-dark text-lg flex items-center gap-1">
                            {genius.name}
                            {genius.verified && (
                              <span className="text-blue-500" title="Verified">
                                ✓
                              </span>
                            )}
                          </h3>
                          <p className="text-sm text-text-gray">
                            {genius.position}
                          </p>
                        </div>
                        <AGAPill
                          variant={genius.rank <= 3 ? 'secondary' : 'neutral'}
                          size="sm"
                        >
                          #{genius.rank}
                        </AGAPill>
                      </div>

                      <p className="text-sm text-text-gray mb-3">
                        {genius.bio}
                      </p>

                      <div className="flex items-center gap-2 mb-3">
                        <AGAPill variant="primary" size="sm">
                          {genius.category}
                        </AGAPill>
                        <AGAPill variant="neutral" size="sm">
                          <MapPin className="w-3 h-3 mr-1" />
                          {genius.country}
                        </AGAPill>
                      </div>

                      <div className="flex items-center gap-6">
                        <div className="flex items-center gap-2 text-sm text-text-gray">
                          <TrendingUp className="w-4 h-4" />
                          <span className="font-semibold">
                            {genius.votes.toLocaleString()}
                          </span>{' '}
                          votes
                        </div>
                        <div className="flex items-center gap-2 text-sm text-text-gray">
                          <Users className="w-4 h-4" />
                          <span className="font-semibold">
                            {genius.followers.toLocaleString()}
                          </span>{' '}
                          followers
                        </div>
                      </div>
                    </div>

                    {/* Actions */}
                    <div className="flex flex-col gap-2 flex-shrink-0">
                      <AGAButton variant="primary" size="sm">
                        Follow
                      </AGAButton>
                      <Link href={`/genius/${genius.id}`}>
                        <AGAButton variant="outline" size="sm">
                          View Profile
                        </AGAButton>
                      </Link>
                    </div>
                  </div>
                </AGACard>
              ))}
            </div>
          )}

          {/* Pagination */}
          <div className="flex justify-center">
            <div className="flex items-center gap-2">
              <AGAButton variant="outline" size="sm">
                Previous
              </AGAButton>
              <AGAButton variant="primary" size="sm">
                1
              </AGAButton>
              <AGAButton variant="outline" size="sm">
                2
              </AGAButton>
              <AGAButton variant="outline" size="sm">
                3
              </AGAButton>
              <AGAButton variant="outline" size="sm">
                Next
              </AGAButton>
            </div>
          </div>
        </div>
      </DashboardLayout>
    </ProtectedRoute>
  );
}
