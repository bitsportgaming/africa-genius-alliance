exports.id=203,exports.ids=[203],exports.modules={7529:()=>{},6438:(e,t,r)=>{Promise.resolve().then(r.bind(r,8143))},5886:(e,t,r)=>{Promise.resolve().then(r.t.bind(r,2994,23)),Promise.resolve().then(r.t.bind(r,6114,23)),Promise.resolve().then(r.t.bind(r,9727,23)),Promise.resolve().then(r.t.bind(r,9671,23)),Promise.resolve().then(r.t.bind(r,1868,23)),Promise.resolve().then(r.t.bind(r,4759,23))},8143:(e,t,r)=>{"use strict";r.d(t,{Providers:()=>l});var a=r(326);r(7577);var i=r(4951),n=r(4976),s=r(8929);let o=new i.S({defaultOptions:{queries:{staleTime:6e4,refetchOnWindowFocus:!1}}});function l({children:e}){return a.jsx(n.aH,{client:o,children:a.jsx(s.Ho,{children:e})})}},6491:(e,t,r)=>{"use strict";r.d(t,{P1:()=>i,iC:()=>n,yh:()=>o,L:()=>s});var a=r(326);r(7577);let i=({variant:e="primary",size:t="md",fullWidth:r=!1,loading:i=!1,leftIcon:n,rightIcon:s,children:o,className:l="",disabled:c,...d})=>{let p=`
    inline-flex items-center justify-center gap-2
    font-semibold rounded-aga
    transition-all duration-200
    focus:outline-none focus:ring-2 focus:ring-offset-2
    disabled:opacity-50 disabled:cursor-not-allowed
    active:scale-95
  `,u={primary:`
      bg-gradient-to-r from-primary to-primary-dark
      text-white
      hover:shadow-aga-lg
      focus:ring-primary
    `,secondary:`
      bg-gradient-to-r from-secondary to-secondary-dark
      text-white
      hover:shadow-aga-lg
      focus:ring-secondary
    `,outline:`
      border-2 border-primary
      text-primary
      hover:bg-primary hover:text-white
      focus:ring-primary
    `,ghost:`
      text-primary
      hover:bg-primary/10
      focus:ring-primary
    `,danger:`
      bg-red-600
      text-white
      hover:bg-red-700
      focus:ring-red-500
    `};return(0,a.jsxs)("button",{className:`
        ${p}
        ${u[e]}
        ${{sm:"px-3 py-1.5 text-sm",md:"px-6 py-3 text-base",lg:"px-8 py-4 text-lg"}[t]}
        ${r?"w-full":""}
        ${l}
      `,disabled:c||i,...d,children:[i&&(0,a.jsxs)("svg",{className:"animate-spin h-4 w-4",xmlns:"http://www.w3.org/2000/svg",fill:"none",viewBox:"0 0 24 24",children:[a.jsx("circle",{className:"opacity-25",cx:"12",cy:"12",r:"10",stroke:"currentColor",strokeWidth:"4"}),a.jsx("path",{className:"opacity-75",fill:"currentColor",d:"M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"})]}),!i&&n&&a.jsx("span",{children:n}),a.jsx("span",{children:o}),!i&&s&&a.jsx("span",{children:s})]})},n=({variant:e="default",padding:t="md",className:r="",children:i,onClick:n,hoverable:s=!1})=>{let o=`
    rounded-aga
    transition-all duration-200
  `,l={default:`
      bg-white
      shadow-aga
    `,hero:`
      bg-gradient-to-br from-secondary/10 to-primary/10
      border border-primary/20
      shadow-aga-lg
    `,outlined:`
      bg-white
      border-2 border-primary/20
    `,elevated:`
      bg-white
      shadow-aga-lg
    `},c=s||n?"hover:shadow-aga-lg hover:scale-[1.02] cursor-pointer":"";return a.jsx("div",{className:`
        ${o}
        ${l[e]}
        ${{none:"",sm:"p-4",md:"p-6",lg:"p-8"}[t]}
        ${c}
        ${r}
      `,onClick:n,children:i})},s=({variant:e="primary",size:t="md",children:r,className:i=""})=>{let n=`
    inline-flex items-center justify-center
    font-medium rounded-full
    whitespace-nowrap
  `;return a.jsx("span",{className:`
        ${n}
        ${{primary:"bg-primary/10 text-primary",secondary:"bg-secondary/10 text-secondary-dark",success:"bg-green-100 text-green-700",warning:"bg-yellow-100 text-yellow-700",danger:"bg-red-100 text-red-700",neutral:"bg-gray-100 text-gray-700"}[e]}
        ${{sm:"px-2 py-0.5 text-xs",md:"px-3 py-1 text-sm",lg:"px-4 py-1.5 text-base"}[t]}
        ${i}
      `,children:r})},o=({selected:e=!1,onClick:t,children:r,className:i=""})=>{let n=`
    inline-flex items-center justify-center
    px-4 py-2
    font-medium text-sm
    rounded-full
    border-2
    transition-all duration-200
    cursor-pointer
    select-none
  `;return a.jsx("button",{type:"button",className:`
        ${n}
        ${e?"bg-primary border-primary text-white shadow-aga":"bg-white border-gray-200 text-gray-700 hover:border-primary/50 hover:bg-primary/5"}
        ${i}
      `,onClick:t,children:r})}},8699:(e,t,r)=>{"use strict";r.d(t,{k:()=>i});var a=r(9341);let i={register:async e=>a.x.post("/auth/register",e),login:async e=>a.x.post("/auth/login",e),getProfile:async e=>a.x.get(`/auth/profile/${e}`),updateProfile:async(e,t)=>a.x.put(`/auth/profile/${e}`,t),completeGeniusOnboarding:async(e,t)=>a.x.put(`/auth/profile/${e}/genius`,t),async uploadProfileImage(e,t){let r=new FormData;return r.append("image",t),a.x.uploadFile(`/auth/profile/${e}/image`,r)}}},9341:(e,t,r)=>{"use strict";r.d(t,{x:()=>n});var a=r(4464);class i{constructor(){this.client=a.Z.create({baseURL:"http://localhost:3000/api",headers:{"Content-Type":"application/json"},timeout:3e4}),this.client.interceptors.request.use(e=>{let t=this.getToken();return t&&(e.headers.Authorization=`Bearer ${t}`),e},e=>Promise.reject(e)),this.client.interceptors.response.use(e=>e,e=>(e.response?.status===401&&this.clearToken(),Promise.reject(e)))}getToken(){return null}setToken(e){}clearToken(){}async get(e,t){return(await this.client.get(e,t)).data}async post(e,t,r){return(await this.client.post(e,t,r)).data}async put(e,t,r){return(await this.client.put(e,t,r)).data}async delete(e,t){return(await this.client.delete(e,t)).data}async uploadFile(e,t,r){return(await this.client.post(e,t,{...r,headers:{...r?.headers,"Content-Type":"multipart/form-data"}})).data}saveToken(e){this.setToken(e)}removeToken(){this.clearToken()}}let n=new i},8929:(e,t,r)=>{"use strict";r.d(t,{Ho:()=>p,aC:()=>u});var a=r(326),i=r(7577),n=r(8408),s=r(5251),o=r(8699),l=r(9341);let c=(0,n.U)()((0,s.tJ)((e,t)=>({user:null,isAuthenticated:!1,isLoading:!1,error:null,login:async t=>{try{e({isLoading:!0,error:null});let r=await o.k.login(t);if(r.success&&r.data){let{user:t,token:a}=r.data;a&&l.x.saveToken(a),e({user:t,isAuthenticated:!0,isLoading:!1})}else throw Error(r.error||"Login failed")}catch(t){throw e({error:t.response?.data?.error||t.message||"Login failed",isLoading:!1}),t}},register:async t=>{try{e({isLoading:!0,error:null});let r=await o.k.register(t);if(r.success&&r.data){let{user:t,token:a}=r.data;a&&l.x.saveToken(a),e({user:t,isAuthenticated:!0,isLoading:!1})}else throw Error(r.error||"Registration failed")}catch(t){throw e({error:t.response?.data?.error||t.message||"Registration failed",isLoading:!1}),t}},logout:()=>{l.x.removeToken(),e({user:null,isAuthenticated:!1,error:null})},updateUser:t=>{e({user:t})},clearError:()=>{e({error:null})},refreshProfile:async()=>{let{user:r}=t();if(r)try{let t=await o.k.getProfile(r._id);t.success&&t.data&&e({user:t.data})}catch(e){console.error("Failed to refresh profile:",e)}}}),{name:"aga-auth-storage",partialize:e=>({user:e.user,isAuthenticated:e.isAuthenticated})})),d=(0,i.createContext)(null);function p({children:e}){let t=c(),[r,n]=(0,i.useState)(!1);return r?a.jsx(d.Provider,{value:t,children:e}):null}function u(){let e=(0,i.useContext)(d);if(!e)throw Error("useAuth must be used within AuthProvider");return e}},4752:(e,t,r)=>{"use strict";r.r(t),r.d(t,{default:()=>d,metadata:()=>c});var a=r(9510);r(7272);var i=r(8570);let n=(0,i.createProxy)(String.raw`/Users/charlpagne/Documents/aga/web-app/app/providers.tsx`),{__esModule:s,$$typeof:o}=n;n.default;let l=(0,i.createProxy)(String.raw`/Users/charlpagne/Documents/aga/web-app/app/providers.tsx#Providers`),c={metadataBase:new URL("https://globalgeniusalliance.org"),title:{default:"Africa Genius Alliance | Merit-Based Leadership Platform",template:"%s | Africa Genius Alliance"},description:"Africa Genius Alliance identifies, elevates, and supports Africa's most capable minds through transparency, ideas, and measurable impact. Join the movement for merit-based leadership.",keywords:["Africa leadership","merit-based platform","African innovation","genius recognition","transparent voting","impact measurement","African excellence","leadership platform","talent discovery","Africa development"],authors:[{name:"Africa Genius Alliance",url:"https://globalgeniusalliance.org"}],creator:"Africa Genius Alliance",publisher:"Africa Genius Alliance",formatDetection:{email:!1,address:!1,telephone:!1},openGraph:{type:"website",locale:"en_US",url:"https://globalgeniusalliance.org",siteName:"Africa Genius Alliance",title:"Africa Genius Alliance | Leadership Earned by Merit. Not Politics.",description:"Join Africa's premier platform for identifying and supporting exceptional talent. Transparent, merit-based, and impact-driven.",images:[{url:"https://globalgeniusalliance.org/og-image.png",width:1200,height:630,alt:"Africa Genius Alliance - Merit-Based Leadership Platform",type:"image/png"}]},twitter:{card:"summary_large_image",site:"@AfricaGenius",creator:"@AfricaGenius",title:"Africa Genius Alliance | Leadership Earned by Merit",description:"Join Africa's premier platform for identifying and supporting exceptional talent through transparent, merit-based recognition.",images:["https://globalgeniusalliance.org/og-image.png"]},robots:{index:!0,follow:!0,googleBot:{index:!0,follow:!0,"max-video-preview":-1,"max-image-preview":"large","max-snippet":-1}},icons:{icon:"/favicon.ico",shortcut:"/favicon.ico",apple:"/apple-touch-icon.png"},manifest:"/site.webmanifest",verification:{},alternates:{canonical:"https://globalgeniusalliance.org"},category:"technology"};function d({children:e}){return(0,a.jsxs)("html",{lang:"en",children:[a.jsx("head",{children:a.jsx("script",{type:"application/ld+json",dangerouslySetInnerHTML:{__html:JSON.stringify({"@context":"https://schema.org","@type":"Organization",name:"Africa Genius Alliance",alternateName:"AGA",url:"https://globalgeniusalliance.org",logo:"https://globalgeniusalliance.org/og-image.png",description:"Africa Genius Alliance identifies, elevates, and supports Africa's most capable minds through transparency, ideas, and measurable impact.",foundingDate:"2024",sameAs:["https://twitter.com/AfricaGenius","https://linkedin.com/company/africa-genius-alliance"],contactPoint:{"@type":"ContactPoint",contactType:"customer support",email:"support@globalgeniusalliance.org"}})}})}),a.jsx("body",{children:a.jsx(l,{children:e})})]})}},7272:()=>{}};