'use client';

import { useAuth } from '@/lib/store/auth-store';
import { AGACard, AGAButton, AGAPill, AGAChip } from '@/components/ui';
import Link from 'next/link';
import {
  Vote,
  Users,
  DollarSign,
  Radio,
  TrendingUp,
  Heart,
  MessageCircle,
  Share2,
  Eye,
  Play,
  ShieldCheck
} from 'lucide-react';
import { useState } from 'react';

export function SupporterDashboard() {
  const { user } = useAuth();
  const [feedFilter, setFeedFilter] = useState<'forYou' | 'following' | 'trending' | 'live'>('forYou');

  // Mock data - Replace with real API calls
  const quickStats = {
    votesCast: 45,
    following: 12,
    donated: 2500,
  };

  const liveStreams = [
    {
      id: 1,
      streamerName: 'Amina Okafor',
      streamerAvatar: 'AO',
      title: 'Town Hall: Education Reform Discussion',
      viewers: 234,
      category: 'Political',
    },
    {
      id: 2,
      streamerName: 'Kwame Mensah',
      streamerAvatar: 'KM',
      title: 'Q&A Session with Supporters',
      viewers: 156,
      category: 'Civic',
    },
  ];

  const trendingGeniuses = [
    { name: 'Zainab Hassan', position: 'Healthcare Minister Candidate', votes: 4567, avatar: 'ZH' },
    { name: 'Thabo Ndlovu', position: 'Education Reform Leader', votes: 4234, avatar: 'TN' },
    { name: 'Fatima Diallo', position: 'Economic Advisor', votes: 3998, avatar: 'FD' },
  ];

  const categories = [
    { name: 'Political', icon: '🏛️', count: 145 },
    { name: 'Oversight', icon: '👁️', count: 89 },
    { name: 'Technical', icon: '⚙️', count: 123 },
    { name: 'Civic', icon: '🤝', count: 67 },
  ];

  const feedPosts = [
    {
      id: 0,
      author: 'AGA Official',
      authorAvatar: 'AGA',
      position: 'Africa Genius Alliance',
      content: '🌍 Welcome to Africa Genius Alliance! Together, we are building a platform where merit drives leadership. Every vote counts, every voice matters. Join us in shaping Africa\'s future!',
      timestamp: '1 hour ago',
      likes: 892,
      comments: 156,
      shares: 78,
      isLiked: false,
      isAdminPost: true,
    },
    {
      id: 1,
      author: 'Amina Okafor',
      authorAvatar: 'AO',
      position: 'Presidential Candidate',
      content: 'Launched our new healthcare initiative today! We\'re working to provide free healthcare to 5 million Nigerians. Your support makes this possible. #HealthcareForAll',
      timestamp: '2 hours ago',
      likes: 234,
      comments: 45,
      shares: 12,
      isLiked: true,
      isAdminPost: false,
    },
    {
      id: 2,
      author: 'Kwame Mensah',
      authorAvatar: 'KM',
      position: 'Minister of Education',
      content: 'Education is the foundation of progress. Today we announced 10,000 scholarships for underprivileged students across Ghana. Together, we rise!',
      timestamp: '5 hours ago',
      likes: 567,
      comments: 89,
      shares: 34,
      isLiked: false,
      isAdminPost: false,
    },
  ];

  return (
    <div className="space-y-8">
      {/* Welcome Section */}
      <div>
        <h1 className="text-4xl font-black text-text-dark mb-2">
          Welcome back, {user?.displayName}!
        </h1>
        <p className="text-lg text-text-gray">
          Discover leaders, cast votes, and shape Africa's future
        </p>
      </div>

      {/* Quick Stats */}
      <section>
        <h2 className="text-2xl font-bold text-text-dark mb-4">Your Impact</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <AGACard variant="elevated" padding="lg">
            <div className="flex items-start gap-4">
              <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center">
                <Vote className="w-6 h-6 text-primary" />
              </div>
              <div>
                <h3 className="text-3xl font-black text-text-dark">
                  {quickStats.votesCast}
                </h3>
                <p className="text-sm text-text-gray mt-1">Votes Cast</p>
              </div>
            </div>
          </AGACard>

          <AGACard variant="elevated" padding="lg">
            <div className="flex items-start gap-4">
              <div className="w-12 h-12 rounded-xl bg-secondary/10 flex items-center justify-center">
                <Users className="w-6 h-6 text-secondary" />
              </div>
              <div>
                <h3 className="text-3xl font-black text-text-dark">
                  {quickStats.following}
                </h3>
                <p className="text-sm text-text-gray mt-1">Following</p>
              </div>
            </div>
          </AGACard>

          <AGACard variant="elevated" padding="lg">
            <div className="flex items-start gap-4">
              <div className="w-12 h-12 rounded-xl bg-green-500/10 flex items-center justify-center">
                <DollarSign className="w-6 h-6 text-green-600" />
              </div>
              <div>
                <h3 className="text-3xl font-black text-text-dark">
                  ${quickStats.donated.toLocaleString()}
                </h3>
                <p className="text-sm text-text-gray mt-1">Donated</p>
              </div>
            </div>
          </AGACard>
        </div>
      </section>

      {/* Live Streams */}
      {liveStreams.length > 0 && (
        <section>
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-2xl font-bold text-text-dark flex items-center gap-2">
              <Radio className="w-6 h-6 text-red-500 animate-pulse" />
              Live Now
            </h2>
            <Link href="/live">
              <AGAButton variant="ghost" size="sm">View All</AGAButton>
            </Link>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {liveStreams.map((stream) => (
              <AGACard
                key={stream.id}
                variant="elevated"
                padding="lg"
                hoverable
                className="relative overflow-hidden"
              >
                <AGAPill
                  variant="danger"
                  size="sm"
                  className="absolute top-4 right-4 animate-pulse"
                >
                  <Radio className="w-3 h-3 mr-1" />
                  LIVE
                </AGAPill>

                <div className="flex items-start gap-4 mb-4">
                  <div className="w-14 h-14 rounded-full bg-gradient-accent flex items-center justify-center text-white font-bold text-lg">
                    {stream.streamerAvatar}
                  </div>
                  <div className="flex-1">
                    <h3 className="font-bold text-text-dark">
                      {stream.streamerName}
                    </h3>
                    <AGAPill variant="neutral" size="sm" className="mt-1">
                      {stream.category}
                    </AGAPill>
                  </div>
                </div>

                <h4 className="font-semibold text-text-dark mb-4">
                  {stream.title}
                </h4>

                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2 text-text-gray text-sm">
                    <Eye className="w-4 h-4" />
                    <span>{stream.viewers} watching</span>
                  </div>
                  <AGAButton variant="primary" size="sm" leftIcon={<Play className="w-4 h-4" />}>
                    Join
                  </AGAButton>
                </div>
              </AGACard>
            ))}
          </div>
        </section>
      )}

      {/* Trending Geniuses */}
      <section>
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-2xl font-bold text-text-dark">Trending Geniuses</h2>
          <Link href="/explore">
            <AGAButton variant="ghost" size="sm">Explore All</AGAButton>
          </Link>
        </div>
        <div className="flex gap-4 overflow-x-auto pb-4">
          {trendingGeniuses.map((genius, index) => (
            <AGACard
              key={index}
              variant="elevated"
              padding="lg"
              hoverable
              className="flex-shrink-0 w-72"
            >
              <div className="text-center">
                <div className="w-20 h-20 rounded-full bg-gradient-accent flex items-center justify-center text-white font-bold text-2xl mx-auto mb-4">
                  {genius.avatar}
                </div>
                <h3 className="font-bold text-text-dark mb-1">
                  {genius.name}
                </h3>
                <p className="text-sm text-text-gray mb-3">
                  {genius.position}
                </p>
                <div className="flex items-center justify-center gap-2 mb-4">
                  <TrendingUp className="w-4 h-4 text-green-500" />
                  <span className="text-sm font-semibold text-text-dark">
                    {genius.votes.toLocaleString()} votes
                  </span>
                </div>
                <AGAButton variant="primary" size="sm" fullWidth>
                  Follow
                </AGAButton>
              </div>
            </AGACard>
          ))}
        </div>
      </section>

      {/* Category Browse */}
      <section>
        <h2 className="text-2xl font-bold text-text-dark mb-4">
          Browse by Category
        </h2>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {categories.map((category, index) => (
            <Link key={index} href={`/explore?category=${category.name.toLowerCase()}`}>
              <AGACard variant="elevated" padding="md" hoverable className="text-center">
                <div className="text-4xl mb-2">{category.icon}</div>
                <h3 className="font-bold text-text-dark mb-1">
                  {category.name}
                </h3>
                <p className="text-sm text-text-gray">
                  {category.count} Geniuses
                </p>
              </AGACard>
            </Link>
          ))}
        </div>
      </section>

      {/* Feed */}
      <section>
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-2xl font-bold text-text-dark">Your Feed</h2>
          <div className="flex gap-2">
            <AGAChip
              selected={feedFilter === 'forYou'}
              onClick={() => setFeedFilter('forYou')}
            >
              For You
            </AGAChip>
            <AGAChip
              selected={feedFilter === 'following'}
              onClick={() => setFeedFilter('following')}
            >
              Following
            </AGAChip>
            <AGAChip
              selected={feedFilter === 'trending'}
              onClick={() => setFeedFilter('trending')}
            >
              Trending
            </AGAChip>
          </div>
        </div>

        <div className="space-y-6">
          {feedPosts.map((post) => (
            <AGACard key={post.id} variant={post.isAdminPost ? 'hero' : 'elevated'} padding="lg" className={post.isAdminPost ? 'border-2 border-yellow-400/30 bg-gradient-to-r from-yellow-50/50 to-amber-50/50' : ''}>
              {/* Admin Post Badge */}
              {post.isAdminPost && (
                <div className="flex items-center gap-2 mb-3 pb-3 border-b border-yellow-400/20">
                  <div className="flex items-center gap-1.5 px-2.5 py-1 bg-gradient-to-r from-yellow-400 to-amber-500 rounded-full">
                    <ShieldCheck className="w-3.5 h-3.5 text-white" />
                    <span className="text-xs font-bold text-white">Official AGA Announcement</span>
                  </div>
                </div>
              )}
              {/* Post Header */}
              <div className="flex items-start gap-4 mb-4">
                <div className={`w-12 h-12 rounded-full flex items-center justify-center text-white font-bold ${post.isAdminPost ? 'bg-gradient-to-br from-yellow-400 to-amber-600' : 'bg-gradient-accent'}`}>
                  {post.isAdminPost ? '✦' : post.authorAvatar}
                </div>
                <div className="flex-1">
                  <div className="flex items-center gap-2">
                    <h3 className="font-bold text-text-dark">{post.author}</h3>
                    {post.isAdminPost && (
                      <div className="flex items-center" title="Verified Admin">
                        <svg className="w-5 h-5" viewBox="0 0 24 24" fill="none">
                          <path d="M9 12l2 2 4-4" stroke="#EAB308" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                          <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z" fill="#FBBF24" stroke="#EAB308" strokeWidth="1"/>
                        </svg>
                      </div>
                    )}
                  </div>
                  <p className="text-sm text-text-gray">{post.position}</p>
                  <p className="text-xs text-text-gray mt-1">{post.timestamp}</p>
                </div>
                {!post.isAdminPost && (
                  <AGAButton variant="ghost" size="sm">
                    Follow
                  </AGAButton>
                )}
              </div>

              {/* Post Content */}
              <p className="text-text-dark mb-4 leading-relaxed">
                {post.content}
              </p>

              {/* Post Actions */}
              <div className="flex items-center gap-6 pt-4 border-t border-gray-200">
                <button
                  className={`flex items-center gap-2 ${
                    post.isLiked ? 'text-red-500' : 'text-text-gray'
                  } hover:text-red-500 transition-colors`}
                >
                  <Heart className={`w-5 h-5 ${post.isLiked ? 'fill-current' : ''}`} />
                  <span className="text-sm font-medium">{post.likes}</span>
                </button>
                <button className="flex items-center gap-2 text-text-gray hover:text-primary transition-colors">
                  <MessageCircle className="w-5 h-5" />
                  <span className="text-sm font-medium">{post.comments}</span>
                </button>
                <button className="flex items-center gap-2 text-text-gray hover:text-primary transition-colors">
                  <Share2 className="w-5 h-5" />
                  <span className="text-sm font-medium">{post.shares}</span>
                </button>
              </div>
            </AGACard>
          ))}
        </div>

        <div className="mt-6 text-center">
          <AGAButton variant="outline">Load More Posts</AGAButton>
        </div>
      </section>
    </div>
  );
}
