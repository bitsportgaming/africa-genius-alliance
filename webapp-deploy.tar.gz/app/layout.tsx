import type { Metadata } from 'next';
import './globals.css';
import { Providers } from './providers';

export const metadata: Metadata = {
  title: 'Africa Genius Alliance | Merit-Based Leadership Platform',
  description: 'Africa Genius Alliance identifies, elevates, and supports Africa\'s most capable minds through transparency, ideas, and measurable impact.',
  keywords: 'Africa, leadership, merit, transparency, genius, voting, impact',
  authors: [{ name: 'Africa Genius Alliance' }],
  openGraph: {
    title: 'Africa Genius Alliance | Merit-Based Leadership Platform',
    description: 'Leadership Earned by Merit. Not Politics.',
    type: 'website',
    locale: 'en_US',
    siteName: 'Africa Genius Alliance',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Africa Genius Alliance',
    description: 'Leadership Earned by Merit. Not Politics.',
  },
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <body>
        <Providers>{children}</Providers>
      </body>
    </html>
  );
}
