import React from 'react';
import { HeroSection } from '@/components/landing/HeroSection';
import { HowItWorksSection } from '@/components/landing/HowItWorksSection';
import { TwoPathsSection } from '@/components/landing/TwoPathsSection';
import { TransparencySection } from '@/components/landing/TransparencySection';
import { Footer } from '@/components/landing/Footer';

export default function LandingPage() {
  return (
    <main className="min-h-screen">
      <HeroSection />
      <HowItWorksSection />
      <TwoPathsSection />
      <TransparencySection />
      <Footer />
    </main>
  );
}
