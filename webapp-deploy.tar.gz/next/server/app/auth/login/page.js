(()=>{var e={};e.id=716,e.ids=[716],e.modules={7849:e=>{"use strict";e.exports=require("next/dist/client/components/action-async-storage.external")},2934:e=>{"use strict";e.exports=require("next/dist/client/components/action-async-storage.external.js")},5403:e=>{"use strict";e.exports=require("next/dist/client/components/request-async-storage.external")},4580:e=>{"use strict";e.exports=require("next/dist/client/components/request-async-storage.external.js")},4749:e=>{"use strict";e.exports=require("next/dist/client/components/static-generation-async-storage.external")},5869:e=>{"use strict";e.exports=require("next/dist/client/components/static-generation-async-storage.external.js")},399:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},9491:e=>{"use strict";e.exports=require("assert")},6113:e=>{"use strict";e.exports=require("crypto")},2361:e=>{"use strict";e.exports=require("events")},7147:e=>{"use strict";e.exports=require("fs")},3685:e=>{"use strict";e.exports=require("http")},5158:e=>{"use strict";e.exports=require("http2")},5687:e=>{"use strict";e.exports=require("https")},1017:e=>{"use strict";e.exports=require("path")},2781:e=>{"use strict";e.exports=require("stream")},6224:e=>{"use strict";e.exports=require("tty")},7310:e=>{"use strict";e.exports=require("url")},3837:e=>{"use strict";e.exports=require("util")},9796:e=>{"use strict";e.exports=require("zlib")},7529:()=>{},2159:(e,t,r)=>{"use strict";r.r(t),r.d(t,{GlobalError:()=>n.a,__next_app__:()=>p,originalPathname:()=>u,pages:()=>d,routeModule:()=>h,tree:()=>c}),r(4595),r(4752),r(5866);var a=r(3191),s=r(8716),i=r(7922),n=r.n(i),o=r(5231),l={};for(let e in o)0>["default","tree","pages","GlobalError","originalPathname","__next_app__","routeModule"].indexOf(e)&&(l[e]=()=>o[e]);r.d(t,l);let c=["",{children:["auth",{children:["login",{children:["__PAGE__",{},{page:[()=>Promise.resolve().then(r.bind(r,4595)),"/Users/charlpagne/Documents/aga/web-app/app/auth/login/page.tsx"]}]},{}]},{}]},{layout:[()=>Promise.resolve().then(r.bind(r,4752)),"/Users/charlpagne/Documents/aga/web-app/app/layout.tsx"],"not-found":[()=>Promise.resolve().then(r.t.bind(r,5866,23)),"next/dist/client/components/not-found-error"]}],d=["/Users/charlpagne/Documents/aga/web-app/app/auth/login/page.tsx"],u="/auth/login/page",p={require:r,loadChunk:()=>Promise.resolve()},h=new a.AppPageRouteModule({definition:{kind:s.x.APP_PAGE,page:"/auth/login/page",pathname:"/auth/login",bundlePath:"",filename:"",appPaths:[]},userland:{loaderTree:c}})},2845:(e,t,r)=>{Promise.resolve().then(r.bind(r,7241))},6438:(e,t,r)=>{Promise.resolve().then(r.bind(r,8143))},5886:(e,t,r)=>{Promise.resolve().then(r.t.bind(r,2994,23)),Promise.resolve().then(r.t.bind(r,6114,23)),Promise.resolve().then(r.t.bind(r,9727,23)),Promise.resolve().then(r.t.bind(r,9671,23)),Promise.resolve().then(r.t.bind(r,1868,23)),Promise.resolve().then(r.t.bind(r,4759,23))},7241:(e,t,r)=>{"use strict";r.r(t),r.d(t,{default:()=>p});var a=r(326),s=r(7577),i=r(5047),n=r(8929),o=r(6491),l=r(434),c=r(5932),d=r(9015),u=r(4230);function p(){let[e,t]=(0,s.useState)(""),[r,p]=(0,s.useState)(""),{login:h,isLoading:m,error:x,clearError:g}=(0,n.aC)(),y=(0,i.useRouter)(),f=async t=>{t.preventDefault(),g();try{await h({email:e,password:r}),y.push("/dashboard")}catch(e){}};return a.jsx("div",{className:"min-h-screen flex items-center justify-center bg-gradient-to-br from-primary via-primary-dark to-background-navy px-4",children:(0,a.jsxs)("div",{className:"w-full max-w-md",children:[a.jsx("div",{className:"text-center mb-8",children:(0,a.jsxs)(l.default,{href:"/",className:"inline-block",children:[a.jsx("h1",{className:"text-4xl font-black text-white",children:"AGA"}),a.jsx("p",{className:"text-white/70 text-sm mt-1",children:"Africa Genius Alliance"})]})}),(0,a.jsxs)(o.iC,{variant:"elevated",padding:"lg",children:[a.jsx("h2",{className:"text-3xl font-black text-text-dark text-center mb-2",children:"Welcome Back"}),a.jsx("p",{className:"text-text-gray text-center mb-6",children:"Sign in to continue your impact"}),x&&a.jsx("div",{className:"mb-4 p-4 bg-red-50 border border-red-200 rounded-aga text-red-700 text-sm",children:x}),(0,a.jsxs)("form",{onSubmit:f,className:"space-y-5",children:[(0,a.jsxs)("div",{children:[a.jsx("label",{className:"block text-sm font-semibold text-text-dark mb-2",children:"Email Address"}),(0,a.jsxs)("div",{className:"relative",children:[a.jsx(c.Z,{className:"absolute left-4 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400"}),a.jsx("input",{type:"email",value:e,onChange:e=>t(e.target.value),required:!0,placeholder:"you@example.com",className:"w-full pl-12 pr-4 py-3 rounded-aga border border-gray-200 focus:border-primary focus:ring-2 focus:ring-primary/20 outline-none transition-all"})]})]}),(0,a.jsxs)("div",{children:[a.jsx("label",{className:"block text-sm font-semibold text-text-dark mb-2",children:"Password"}),(0,a.jsxs)("div",{className:"relative",children:[a.jsx(d.Z,{className:"absolute left-4 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400"}),a.jsx("input",{type:"password",value:r,onChange:e=>p(e.target.value),required:!0,placeholder:"••••••••",className:"w-full pl-12 pr-4 py-3 rounded-aga border border-gray-200 focus:border-primary focus:ring-2 focus:ring-primary/20 outline-none transition-all"})]})]}),(0,a.jsxs)("div",{className:"flex items-center justify-between text-sm",children:[(0,a.jsxs)("label",{className:"flex items-center gap-2 cursor-pointer",children:[a.jsx("input",{type:"checkbox",className:"w-4 h-4 text-primary border-gray-300 rounded focus:ring-primary"}),a.jsx("span",{className:"text-text-gray",children:"Remember me"})]}),a.jsx(l.default,{href:"/auth/forgot-password",className:"text-primary font-semibold hover:underline",children:"Forgot password?"})]}),a.jsx(o.P1,{type:"submit",variant:"primary",size:"lg",fullWidth:!0,loading:m,rightIcon:m?void 0:a.jsx(u.Z,{className:"w-5 h-5"}),children:"Sign In"})]}),a.jsx("div",{className:"mt-6 pt-6 border-t border-gray-200",children:(0,a.jsxs)("p",{className:"text-center text-sm text-text-gray",children:["Don't have an account?"," ",a.jsx(l.default,{href:"/auth/signup",className:"text-primary font-semibold hover:underline",children:"Create account"})]})}),a.jsx("div",{className:"mt-4 text-center",children:a.jsx(l.default,{href:"/",className:"text-sm text-text-gray hover:text-primary transition-colors",children:"← Back to home"})})]})]})})}},8143:(e,t,r)=>{"use strict";r.d(t,{Providers:()=>l});var a=r(326);r(7577);var s=r(4951),i=r(4976),n=r(8929);let o=new s.S({defaultOptions:{queries:{staleTime:6e4,refetchOnWindowFocus:!1}}});function l({children:e}){return a.jsx(i.aH,{client:o,children:a.jsx(n.Ho,{children:e})})}},6491:(e,t,r)=>{"use strict";r.d(t,{P1:()=>s,iC:()=>i,yh:()=>o,L:()=>n});var a=r(326);r(7577);let s=({variant:e="primary",size:t="md",fullWidth:r=!1,loading:s=!1,leftIcon:i,rightIcon:n,children:o,className:l="",disabled:c,...d})=>{let u=`
    inline-flex items-center justify-center gap-2
    font-semibold rounded-aga
    transition-all duration-200
    focus:outline-none focus:ring-2 focus:ring-offset-2
    disabled:opacity-50 disabled:cursor-not-allowed
    active:scale-95
  `,p={primary:`
      bg-gradient-to-r from-primary to-primary-dark
      text-white
      hover:shadow-aga-lg
      focus:ring-primary
    `,secondary:`
      bg-gradient-to-r from-secondary to-secondary-dark
      text-white
      hover:shadow-aga-lg
      focus:ring-secondary
    `,outline:`
      border-2 border-primary
      text-primary
      hover:bg-primary hover:text-white
      focus:ring-primary
    `,ghost:`
      text-primary
      hover:bg-primary/10
      focus:ring-primary
    `,danger:`
      bg-red-600
      text-white
      hover:bg-red-700
      focus:ring-red-500
    `};return(0,a.jsxs)("button",{className:`
        ${u}
        ${p[e]}
        ${{sm:"px-3 py-1.5 text-sm",md:"px-6 py-3 text-base",lg:"px-8 py-4 text-lg"}[t]}
        ${r?"w-full":""}
        ${l}
      `,disabled:c||s,...d,children:[s&&(0,a.jsxs)("svg",{className:"animate-spin h-4 w-4",xmlns:"http://www.w3.org/2000/svg",fill:"none",viewBox:"0 0 24 24",children:[a.jsx("circle",{className:"opacity-25",cx:"12",cy:"12",r:"10",stroke:"currentColor",strokeWidth:"4"}),a.jsx("path",{className:"opacity-75",fill:"currentColor",d:"M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"})]}),!s&&i&&a.jsx("span",{children:i}),a.jsx("span",{children:o}),!s&&n&&a.jsx("span",{children:n})]})},i=({variant:e="default",padding:t="md",className:r="",children:s,onClick:i,hoverable:n=!1})=>{let o=`
    rounded-aga
    transition-all duration-200
  `,l={default:`
      bg-white
      shadow-aga
    `,hero:`
      bg-gradient-to-br from-secondary/10 to-primary/10
      border border-primary/20
      shadow-aga-lg
    `,outlined:`
      bg-white
      border-2 border-primary/20
    `,elevated:`
      bg-white
      shadow-aga-lg
    `},c=n||i?"hover:shadow-aga-lg hover:scale-[1.02] cursor-pointer":"";return a.jsx("div",{className:`
        ${o}
        ${l[e]}
        ${{none:"",sm:"p-4",md:"p-6",lg:"p-8"}[t]}
        ${c}
        ${r}
      `,onClick:i,children:s})},n=({variant:e="primary",size:t="md",children:r,className:s=""})=>{let i=`
    inline-flex items-center justify-center
    font-medium rounded-full
    whitespace-nowrap
  `;return a.jsx("span",{className:`
        ${i}
        ${{primary:"bg-primary/10 text-primary",secondary:"bg-secondary/10 text-secondary-dark",success:"bg-green-100 text-green-700",warning:"bg-yellow-100 text-yellow-700",danger:"bg-red-100 text-red-700",neutral:"bg-gray-100 text-gray-700"}[e]}
        ${{sm:"px-2 py-0.5 text-xs",md:"px-3 py-1 text-sm",lg:"px-4 py-1.5 text-base"}[t]}
        ${s}
      `,children:r})},o=({selected:e=!1,onClick:t,children:r,className:s=""})=>{let i=`
    inline-flex items-center justify-center
    px-4 py-2
    font-medium text-sm
    rounded-full
    border-2
    transition-all duration-200
    cursor-pointer
    select-none
  `;return a.jsx("button",{type:"button",className:`
        ${i}
        ${e?"bg-primary border-primary text-white shadow-aga":"bg-white border-gray-200 text-gray-700 hover:border-primary/50 hover:bg-primary/5"}
        ${s}
      `,onClick:t,children:r})}},8699:(e,t,r)=>{"use strict";r.d(t,{k:()=>s});var a=r(9341);let s={register:async e=>a.x.post("/auth/register",e),login:async e=>a.x.post("/auth/login",e),getProfile:async e=>a.x.get(`/auth/profile/${e}`),updateProfile:async(e,t)=>a.x.put(`/auth/profile/${e}`,t),completeGeniusOnboarding:async(e,t)=>a.x.put(`/auth/profile/${e}/genius`,t),async uploadProfileImage(e,t){let r=new FormData;return r.append("image",t),a.x.uploadFile(`/auth/profile/${e}/image`,r)}}},9341:(e,t,r)=>{"use strict";r.d(t,{x:()=>i});var a=r(4464);class s{constructor(){this.client=a.Z.create({baseURL:"http://localhost:3000/api",headers:{"Content-Type":"application/json"},timeout:3e4}),this.client.interceptors.request.use(e=>{let t=this.getToken();return t&&(e.headers.Authorization=`Bearer ${t}`),e},e=>Promise.reject(e)),this.client.interceptors.response.use(e=>e,e=>(e.response?.status===401&&this.clearToken(),Promise.reject(e)))}getToken(){return null}setToken(e){}clearToken(){}async get(e,t){return(await this.client.get(e,t)).data}async post(e,t,r){return(await this.client.post(e,t,r)).data}async put(e,t,r){return(await this.client.put(e,t,r)).data}async delete(e,t){return(await this.client.delete(e,t)).data}async uploadFile(e,t,r){return(await this.client.post(e,t,{...r,headers:{...r?.headers,"Content-Type":"multipart/form-data"}})).data}saveToken(e){this.setToken(e)}removeToken(){this.clearToken()}}let i=new s},8929:(e,t,r)=>{"use strict";r.d(t,{Ho:()=>u,aC:()=>p});var a=r(326),s=r(7577),i=r(8408),n=r(5251),o=r(8699),l=r(9341);let c=(0,i.U)()((0,n.tJ)((e,t)=>({user:null,isAuthenticated:!1,isLoading:!1,error:null,login:async t=>{try{e({isLoading:!0,error:null});let r=await o.k.login(t);if(r.success&&r.data){let{user:t,token:a}=r.data;a&&l.x.saveToken(a),e({user:t,isAuthenticated:!0,isLoading:!1})}else throw Error(r.error||"Login failed")}catch(t){throw e({error:t.response?.data?.error||t.message||"Login failed",isLoading:!1}),t}},register:async t=>{try{e({isLoading:!0,error:null});let r=await o.k.register(t);if(r.success&&r.data){let{user:t,token:a}=r.data;a&&l.x.saveToken(a),e({user:t,isAuthenticated:!0,isLoading:!1})}else throw Error(r.error||"Registration failed")}catch(t){throw e({error:t.response?.data?.error||t.message||"Registration failed",isLoading:!1}),t}},logout:()=>{l.x.removeToken(),e({user:null,isAuthenticated:!1,error:null})},updateUser:t=>{e({user:t})},clearError:()=>{e({error:null})},refreshProfile:async()=>{let{user:r}=t();if(r)try{let t=await o.k.getProfile(r._id);t.success&&t.data&&e({user:t.data})}catch(e){console.error("Failed to refresh profile:",e)}}}),{name:"aga-auth-storage",partialize:e=>({user:e.user,isAuthenticated:e.isAuthenticated})})),d=(0,s.createContext)(null);function u({children:e}){let t=c(),[r,i]=(0,s.useState)(!1);return r?a.jsx(d.Provider,{value:t,children:e}):null}function p(){let e=(0,s.useContext)(d);if(!e)throw Error("useAuth must be used within AuthProvider");return e}},4230:(e,t,r)=>{"use strict";r.d(t,{Z:()=>a});/**
 * @license lucide-react v0.469.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let a=(0,r(2881).Z)("ArrowRight",[["path",{d:"M5 12h14",key:"1ays0h"}],["path",{d:"m12 5 7 7-7 7",key:"xquz4c"}]])},9015:(e,t,r)=>{"use strict";r.d(t,{Z:()=>a});/**
 * @license lucide-react v0.469.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let a=(0,r(2881).Z)("Lock",[["rect",{width:"18",height:"11",x:"3",y:"11",rx:"2",ry:"2",key:"1w4ew1"}],["path",{d:"M7 11V7a5 5 0 0 1 10 0v4",key:"fwvmzm"}]])},5932:(e,t,r)=>{"use strict";r.d(t,{Z:()=>a});/**
 * @license lucide-react v0.469.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let a=(0,r(2881).Z)("Mail",[["rect",{width:"20",height:"16",x:"2",y:"4",rx:"2",key:"18n3k1"}],["path",{d:"m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7",key:"1ocrg3"}]])},5047:(e,t,r)=>{"use strict";var a=r(7389);r.o(a,"usePathname")&&r.d(t,{usePathname:function(){return a.usePathname}}),r.o(a,"useRouter")&&r.d(t,{useRouter:function(){return a.useRouter}}),r.o(a,"useSearchParams")&&r.d(t,{useSearchParams:function(){return a.useSearchParams}})},4595:(e,t,r)=>{"use strict";r.r(t),r.d(t,{$$typeof:()=>n,__esModule:()=>i,default:()=>o});var a=r(8570);let s=(0,a.createProxy)(String.raw`/Users/charlpagne/Documents/aga/web-app/app/auth/login/page.tsx`),{__esModule:i,$$typeof:n}=s;s.default;let o=(0,a.createProxy)(String.raw`/Users/charlpagne/Documents/aga/web-app/app/auth/login/page.tsx#default`)},4752:(e,t,r)=>{"use strict";r.r(t),r.d(t,{default:()=>d,metadata:()=>c});var a=r(9510);r(7272);var s=r(8570);let i=(0,s.createProxy)(String.raw`/Users/charlpagne/Documents/aga/web-app/app/providers.tsx`),{__esModule:n,$$typeof:o}=i;i.default;let l=(0,s.createProxy)(String.raw`/Users/charlpagne/Documents/aga/web-app/app/providers.tsx#Providers`),c={title:"Africa Genius Alliance | Merit-Based Leadership Platform",description:"Africa Genius Alliance identifies, elevates, and supports Africa's most capable minds through transparency, ideas, and measurable impact.",keywords:"Africa, leadership, merit, transparency, genius, voting, impact",authors:[{name:"Africa Genius Alliance"}],openGraph:{title:"Africa Genius Alliance | Merit-Based Leadership Platform",description:"Leadership Earned by Merit. Not Politics.",type:"website",locale:"en_US",siteName:"Africa Genius Alliance"},twitter:{card:"summary_large_image",title:"Africa Genius Alliance",description:"Leadership Earned by Merit. Not Politics."}};function d({children:e}){return a.jsx("html",{lang:"en",children:a.jsx("body",{children:a.jsx(l,{children:e})})})}},7272:()=>{}};var t=require("../../../webpack-runtime.js");t.C(e);var r=e=>t(t.s=e),a=t.X(0,[904,705],()=>r(2159));module.exports=a})();