exports.id=380,exports.ids=[380],exports.modules={7529:()=>{},6438:(e,t,r)=>{Promise.resolve().then(r.bind(r,8143))},5886:(e,t,r)=>{Promise.resolve().then(r.t.bind(r,2994,23)),Promise.resolve().then(r.t.bind(r,6114,23)),Promise.resolve().then(r.t.bind(r,9727,23)),Promise.resolve().then(r.t.bind(r,9671,23)),Promise.resolve().then(r.t.bind(r,1868,23)),Promise.resolve().then(r.t.bind(r,4759,23))},8143:(e,t,r)=>{"use strict";r.d(t,{Providers:()=>o});var a=r(326);r(7577);var s=r(4951),i=r(4976),n=r(8929);let l=new s.S({defaultOptions:{queries:{staleTime:6e4,refetchOnWindowFocus:!1}}});function o({children:e}){return a.jsx(i.aH,{client:l,children:a.jsx(n.Ho,{children:e})})}},3371:(e,t,r)=>{"use strict";r.d(t,{c:()=>w});var a=r(326),s=r(8929),i=r(1923),n=r(434),l=r(5047),o=r(2881);/**
 * @license lucide-react v0.469.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let c=(0,o.Z)("House",[["path",{d:"M15 21v-8a1 1 0 0 0-1-1h-4a1 1 0 0 0-1 1v8",key:"5wwlr5"}],["path",{d:"M3 10a2 2 0 0 1 .709-1.528l7-5.999a2 2 0 0 1 2.582 0l7 5.999A2 2 0 0 1 21 10v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z",key:"1d0kgt"}]]),d=(0,o.Z)("Compass",[["path",{d:"m16.24 7.76-1.804 5.411a2 2 0 0 1-1.265 1.265L7.76 16.24l1.804-5.411a2 2 0 0 1 1.265-1.265z",key:"9ktpf1"}],["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}]]);var h=r(2959);/**
 * @license lucide-react v0.469.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let u=(0,o.Z)("CirclePlus",[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["path",{d:"M8 12h8",key:"1wcyev"}],["path",{d:"M12 8v8",key:"napkw2"}]]);var m=r(7069);/**
 * @license lucide-react v0.469.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let p=(0,o.Z)("User",[["path",{d:"M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2",key:"975kel"}],["circle",{cx:"12",cy:"7",r:"4",key:"17ys0d"}]]),x=(0,o.Z)("Bell",[["path",{d:"M10.268 21a2 2 0 0 0 3.464 0",key:"vwvbt9"}],["path",{d:"M3.262 15.326A1 1 0 0 0 4 17h16a1 1 0 0 0 .74-1.673C19.41 13.956 18 12.499 18 8A6 6 0 0 0 6 8c0 4.499-1.411 5.956-2.738 7.326",key:"11g9vi"}]]);var g=r(8378),y=r(1810),f=r(4019);/**
 * @license lucide-react v0.469.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let b=(0,o.Z)("Menu",[["line",{x1:"4",x2:"20",y1:"12",y2:"12",key:"1e0a9i"}],["line",{x1:"4",x2:"20",y1:"6",y2:"6",key:"1owob3"}],["line",{x1:"4",x2:"20",y1:"18",y2:"18",key:"yk5zj1"}]]);var v=r(7577);function w({children:e}){let{user:t,logout:r}=(0,s.aC)(),o=(0,l.usePathname)(),w=(0,l.useRouter)(),[j,N]=(0,v.useState)(!1),[k,P]=(0,v.useState)(!1),A=t?.role===i.i4.GENIUS,C=[{name:"Home",href:"/dashboard",icon:c,show:!0},{name:"Explore",href:"/explore",icon:d,show:!0},{name:"Vote",href:"/vote",icon:h.Z,show:!A},{name:"Create",href:"/create",icon:u,show:A},{name:"Impact",href:"/impact",icon:m.Z,show:!0},{name:"Profile",href:"/profile",icon:p,show:!0}].filter(e=>e.show),E=()=>{r(),w.push("/")};return(0,a.jsxs)("div",{className:"min-h-screen bg-background-cream",children:[(0,a.jsxs)("nav",{className:"bg-white border-b border-gray-200 sticky top-0 z-40 shadow-sm",children:[a.jsx("div",{className:"container mx-auto px-4",children:(0,a.jsxs)("div",{className:"flex items-center justify-between h-16",children:[(0,a.jsxs)(n.default,{href:"/dashboard",className:"flex items-center gap-2",children:[a.jsx("div",{className:"w-10 h-10 rounded-xl bg-gradient-primary flex items-center justify-center",children:a.jsx("span",{className:"text-white font-black text-xl",children:"A"})}),a.jsx("span",{className:"text-2xl font-black text-primary hidden sm:block",children:"AGA"})]}),a.jsx("div",{className:"hidden md:flex items-center gap-2",children:C.map(e=>{let t=e.icon,r=o===e.href;return(0,a.jsxs)(n.default,{href:e.href,className:`flex items-center gap-2 px-4 py-2 rounded-lg font-medium transition-all duration-200 ${r?"bg-primary text-white shadow-aga":"text-gray-700 hover:bg-gray-100"}`,children:[a.jsx(t,{className:"w-5 h-5"}),a.jsx("span",{children:e.name})]},e.name)})}),(0,a.jsxs)("div",{className:"flex items-center gap-3",children:[(0,a.jsxs)("button",{className:"relative p-2 hover:bg-gray-100 rounded-full transition-colors",children:[a.jsx(x,{className:"w-6 h-6 text-gray-700"}),a.jsx("span",{className:"absolute top-1 right-1 w-2 h-2 bg-secondary rounded-full animate-pulse"})]}),(0,a.jsxs)("div",{className:"relative hidden md:block",children:[(0,a.jsxs)("button",{onClick:()=>P(!k),className:"flex items-center gap-3 p-2 hover:bg-gray-100 rounded-lg transition-colors",children:[a.jsx("div",{className:"w-10 h-10 rounded-full bg-gradient-accent flex items-center justify-center text-white font-bold",children:t?.displayName?.[0]?.toUpperCase()||"U"}),(0,a.jsxs)("div",{className:"text-left hidden lg:block",children:[a.jsx("div",{className:"text-sm font-semibold text-text-dark",children:t?.displayName}),a.jsx("div",{className:"text-xs text-text-gray capitalize",children:t?.role===i.i4.GENIUS?"Genius":"Supporter"})]})]}),k&&(0,a.jsxs)(a.Fragment,{children:[a.jsx("div",{className:"fixed inset-0 z-40",onClick:()=>P(!1)}),(0,a.jsxs)("div",{className:"absolute right-0 mt-2 w-56 bg-white rounded-aga shadow-aga-lg border border-gray-200 py-2 z-50",children:[(0,a.jsxs)("div",{className:"px-4 py-3 border-b border-gray-200",children:[a.jsx("p",{className:"text-sm font-semibold text-text-dark",children:t?.displayName}),a.jsx("p",{className:"text-xs text-text-gray",children:t?.email})]}),(0,a.jsxs)(n.default,{href:"/profile",className:"flex items-center gap-3 px-4 py-2 hover:bg-gray-50 transition-colors",onClick:()=>P(!1),children:[a.jsx(p,{className:"w-4 h-4 text-gray-600"}),a.jsx("span",{className:"text-sm text-text-dark",children:"Profile"})]}),(0,a.jsxs)(n.default,{href:"/settings",className:"flex items-center gap-3 px-4 py-2 hover:bg-gray-50 transition-colors",onClick:()=>P(!1),children:[a.jsx(g.Z,{className:"w-4 h-4 text-gray-600"}),a.jsx("span",{className:"text-sm text-text-dark",children:"Settings"})]}),a.jsx("hr",{className:"my-2 border-gray-200"}),(0,a.jsxs)("button",{onClick:E,className:"w-full flex items-center gap-3 px-4 py-2 hover:bg-red-50 transition-colors text-left",children:[a.jsx(y.Z,{className:"w-4 h-4 text-red-600"}),a.jsx("span",{className:"text-sm text-red-600",children:"Logout"})]})]})]})]}),a.jsx("button",{onClick:()=>N(!j),className:"md:hidden p-2 hover:bg-gray-100 rounded-lg transition-colors",children:j?a.jsx(f.Z,{className:"w-6 h-6 text-gray-700"}):a.jsx(b,{className:"w-6 h-6 text-gray-700"})})]})]})}),j&&a.jsx("div",{className:"md:hidden border-t border-gray-200 bg-white",children:(0,a.jsxs)("div",{className:"container mx-auto px-4 py-4 space-y-2",children:[C.map(e=>{let t=e.icon,r=o===e.href;return(0,a.jsxs)(n.default,{href:e.href,className:`flex items-center gap-3 px-4 py-3 rounded-lg font-medium transition-all ${r?"bg-primary text-white":"text-gray-700 hover:bg-gray-100"}`,onClick:()=>N(!1),children:[a.jsx(t,{className:"w-5 h-5"}),a.jsx("span",{children:e.name})]},e.name)}),a.jsx("hr",{className:"my-2 border-gray-200"}),(0,a.jsxs)("button",{onClick:E,className:"w-full flex items-center gap-3 px-4 py-3 rounded-lg text-red-600 hover:bg-red-50 transition-colors text-left font-medium",children:[a.jsx(y.Z,{className:"w-5 h-5"}),a.jsx("span",{children:"Logout"})]})]})})]}),a.jsx("main",{className:"container mx-auto px-4 py-8",children:e})]})}},5371:(e,t,r)=>{"use strict";r.d(t,{i:()=>n});var a=r(326);r(7577);var s=r(5047),i=r(8929);function n({children:e,requiredRole:t}){let{user:r,isAuthenticated:n}=(0,i.aC)();return((0,s.useRouter)(),!n||t&&r?.role!==t)?a.jsx("div",{className:"min-h-screen flex items-center justify-center bg-background-cream",children:(0,a.jsxs)("div",{className:"text-center",children:[a.jsx("div",{className:"w-16 h-16 border-4 border-primary border-t-transparent rounded-full animate-spin mx-auto mb-4"}),a.jsx("p",{className:"text-text-gray",children:"Loading..."})]})}):a.jsx(a.Fragment,{children:e})}},6491:(e,t,r)=>{"use strict";r.d(t,{P1:()=>s,iC:()=>i,yh:()=>l,L:()=>n});var a=r(326);r(7577);let s=({variant:e="primary",size:t="md",fullWidth:r=!1,loading:s=!1,leftIcon:i,rightIcon:n,children:l,className:o="",disabled:c,...d})=>{let h=`
    inline-flex items-center justify-center gap-2
    font-semibold rounded-aga
    transition-all duration-200
    focus:outline-none focus:ring-2 focus:ring-offset-2
    disabled:opacity-50 disabled:cursor-not-allowed
    active:scale-95
  `,u={primary:`
      bg-gradient-to-r from-primary to-primary-dark
      text-white
      hover:shadow-aga-lg
      focus:ring-primary
    `,secondary:`
      bg-gradient-to-r from-secondary to-secondary-dark
      text-white
      hover:shadow-aga-lg
      focus:ring-secondary
    `,outline:`
      border-2 border-primary
      text-primary
      hover:bg-primary hover:text-white
      focus:ring-primary
    `,ghost:`
      text-primary
      hover:bg-primary/10
      focus:ring-primary
    `,danger:`
      bg-red-600
      text-white
      hover:bg-red-700
      focus:ring-red-500
    `};return(0,a.jsxs)("button",{className:`
        ${h}
        ${u[e]}
        ${{sm:"px-3 py-1.5 text-sm",md:"px-6 py-3 text-base",lg:"px-8 py-4 text-lg"}[t]}
        ${r?"w-full":""}
        ${o}
      `,disabled:c||s,...d,children:[s&&(0,a.jsxs)("svg",{className:"animate-spin h-4 w-4",xmlns:"http://www.w3.org/2000/svg",fill:"none",viewBox:"0 0 24 24",children:[a.jsx("circle",{className:"opacity-25",cx:"12",cy:"12",r:"10",stroke:"currentColor",strokeWidth:"4"}),a.jsx("path",{className:"opacity-75",fill:"currentColor",d:"M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"})]}),!s&&i&&a.jsx("span",{children:i}),a.jsx("span",{children:l}),!s&&n&&a.jsx("span",{children:n})]})},i=({variant:e="default",padding:t="md",className:r="",children:s,onClick:i,hoverable:n=!1})=>{let l=`
    rounded-aga
    transition-all duration-200
  `,o={default:`
      bg-white
      shadow-aga
    `,hero:`
      bg-gradient-to-br from-secondary/10 to-primary/10
      border border-primary/20
      shadow-aga-lg
    `,outlined:`
      bg-white
      border-2 border-primary/20
    `,elevated:`
      bg-white
      shadow-aga-lg
    `},c=n||i?"hover:shadow-aga-lg hover:scale-[1.02] cursor-pointer":"";return a.jsx("div",{className:`
        ${l}
        ${o[e]}
        ${{none:"",sm:"p-4",md:"p-6",lg:"p-8"}[t]}
        ${c}
        ${r}
      `,onClick:i,children:s})},n=({variant:e="primary",size:t="md",children:r,className:s=""})=>{let i=`
    inline-flex items-center justify-center
    font-medium rounded-full
    whitespace-nowrap
  `;return a.jsx("span",{className:`
        ${i}
        ${{primary:"bg-primary/10 text-primary",secondary:"bg-secondary/10 text-secondary-dark",success:"bg-green-100 text-green-700",warning:"bg-yellow-100 text-yellow-700",danger:"bg-red-100 text-red-700",neutral:"bg-gray-100 text-gray-700"}[e]}
        ${{sm:"px-2 py-0.5 text-xs",md:"px-3 py-1 text-sm",lg:"px-4 py-1.5 text-base"}[t]}
        ${s}
      `,children:r})},l=({selected:e=!1,onClick:t,children:r,className:s=""})=>{let i=`
    inline-flex items-center justify-center
    px-4 py-2
    font-medium text-sm
    rounded-full
    border-2
    transition-all duration-200
    cursor-pointer
    select-none
  `;return a.jsx("button",{type:"button",className:`
        ${i}
        ${e?"bg-primary border-primary text-white shadow-aga":"bg-white border-gray-200 text-gray-700 hover:border-primary/50 hover:bg-primary/5"}
        ${s}
      `,onClick:t,children:r})}},8699:(e,t,r)=>{"use strict";r.d(t,{k:()=>s});var a=r(9341);let s={register:async e=>a.x.post("/auth/register",e),login:async e=>a.x.post("/auth/login",e),getProfile:async e=>a.x.get(`/auth/profile/${e}`),updateProfile:async(e,t)=>a.x.put(`/auth/profile/${e}`,t),completeGeniusOnboarding:async(e,t)=>a.x.put(`/auth/profile/${e}/genius`,t),async uploadProfileImage(e,t){let r=new FormData;return r.append("image",t),a.x.uploadFile(`/auth/profile/${e}/image`,r)}}},9341:(e,t,r)=>{"use strict";r.d(t,{x:()=>i});var a=r(4464);class s{constructor(){this.client=a.Z.create({baseURL:"http://localhost:3000/api",headers:{"Content-Type":"application/json"},timeout:3e4}),this.client.interceptors.request.use(e=>{let t=this.getToken();return t&&(e.headers.Authorization=`Bearer ${t}`),e},e=>Promise.reject(e)),this.client.interceptors.response.use(e=>e,e=>(e.response?.status===401&&this.clearToken(),Promise.reject(e)))}getToken(){return null}setToken(e){}clearToken(){}async get(e,t){return(await this.client.get(e,t)).data}async post(e,t,r){return(await this.client.post(e,t,r)).data}async put(e,t,r){return(await this.client.put(e,t,r)).data}async delete(e,t){return(await this.client.delete(e,t)).data}async uploadFile(e,t,r){return(await this.client.post(e,t,{...r,headers:{...r?.headers,"Content-Type":"multipart/form-data"}})).data}saveToken(e){this.setToken(e)}removeToken(){this.clearToken()}}let i=new s},8929:(e,t,r)=>{"use strict";r.d(t,{Ho:()=>h,aC:()=>u});var a=r(326),s=r(7577),i=r(8408),n=r(5251),l=r(8699),o=r(9341);let c=(0,i.U)()((0,n.tJ)((e,t)=>({user:null,isAuthenticated:!1,isLoading:!1,error:null,login:async t=>{try{e({isLoading:!0,error:null});let r=await l.k.login(t);if(r.success&&r.data){let{user:t,token:a}=r.data;a&&o.x.saveToken(a),e({user:t,isAuthenticated:!0,isLoading:!1})}else throw Error(r.error||"Login failed")}catch(t){throw e({error:t.response?.data?.error||t.message||"Login failed",isLoading:!1}),t}},register:async t=>{try{e({isLoading:!0,error:null});let r=await l.k.register(t);if(r.success&&r.data){let{user:t,token:a}=r.data;a&&o.x.saveToken(a),e({user:t,isAuthenticated:!0,isLoading:!1})}else throw Error(r.error||"Registration failed")}catch(t){throw e({error:t.response?.data?.error||t.message||"Registration failed",isLoading:!1}),t}},logout:()=>{o.x.removeToken(),e({user:null,isAuthenticated:!1,error:null})},updateUser:t=>{e({user:t})},clearError:()=>{e({error:null})},refreshProfile:async()=>{let{user:r}=t();if(r)try{let t=await l.k.getProfile(r._id);t.success&&t.data&&e({user:t.data})}catch(e){console.error("Failed to refresh profile:",e)}}}),{name:"aga-auth-storage",partialize:e=>({user:e.user,isAuthenticated:e.isAuthenticated})})),d=(0,s.createContext)(null);function h({children:e}){let t=c(),[r,i]=(0,s.useState)(!1);return r?a.jsx(d.Provider,{value:t,children:e}):null}function u(){let e=(0,s.useContext)(d);if(!e)throw Error("useAuth must be used within AuthProvider");return e}},1810:(e,t,r)=>{"use strict";r.d(t,{Z:()=>a});/**
 * @license lucide-react v0.469.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let a=(0,r(2881).Z)("LogOut",[["path",{d:"M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4",key:"1uf3rs"}],["polyline",{points:"16 17 21 12 16 7",key:"1gabdz"}],["line",{x1:"21",x2:"9",y1:"12",y2:"12",key:"1uyos4"}]])},8378:(e,t,r)=>{"use strict";r.d(t,{Z:()=>a});/**
 * @license lucide-react v0.469.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let a=(0,r(2881).Z)("Settings",[["path",{d:"M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 0 0 1-1-1.74v-.5a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z",key:"1qme2f"}],["circle",{cx:"12",cy:"12",r:"3",key:"1v7zrd"}]])},7069:(e,t,r)=>{"use strict";r.d(t,{Z:()=>a});/**
 * @license lucide-react v0.469.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let a=(0,r(2881).Z)("TrendingUp",[["polyline",{points:"22 7 13.5 15.5 8.5 10.5 2 17",key:"126l90"}],["polyline",{points:"16 7 22 7 22 13",key:"kwv8wd"}]])},2959:(e,t,r)=>{"use strict";r.d(t,{Z:()=>a});/**
 * @license lucide-react v0.469.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let a=(0,r(2881).Z)("Vote",[["path",{d:"m9 12 2 2 4-4",key:"dzmm74"}],["path",{d:"M5 7c0-1.1.9-2 2-2h10a2 2 0 0 1 2 2v12H5V7Z",key:"1ezoue"}],["path",{d:"M22 19H2",key:"nuriw5"}]])},4019:(e,t,r)=>{"use strict";r.d(t,{Z:()=>a});/**
 * @license lucide-react v0.469.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let a=(0,r(2881).Z)("X",[["path",{d:"M18 6 6 18",key:"1bl5f8"}],["path",{d:"m6 6 12 12",key:"d8bk6v"}]])},5047:(e,t,r)=>{"use strict";var a=r(7389);r.o(a,"usePathname")&&r.d(t,{usePathname:function(){return a.usePathname}}),r.o(a,"useRouter")&&r.d(t,{useRouter:function(){return a.useRouter}}),r.o(a,"useSearchParams")&&r.d(t,{useSearchParams:function(){return a.useSearchParams}})},1923:(e,t,r)=>{"use strict";var a,s,i,n,l,o;r.d(t,{i4:()=>a}),function(e){e.GENIUS="genius",e.SUPPORTER="regular",e.ADMIN="admin",e.SUPERADMIN="superadmin"}(a||(a={})),function(e){e.UNVERIFIED="unverified",e.PENDING="pending",e.VERIFIED="verified"}(s||(s={})),function(e){e.POLITICAL="Political",e.OVERSIGHT="Oversight",e.TECHNICAL="Technical",e.CIVIC="Civic"}(i||(i={})),function(e){e.TEXT="text",e.IMAGE="image",e.VIDEO="video",e.LIVE_ANNOUNCEMENT="liveAnnouncement"}(n||(n={})),function(e){e.NONE="none",e.IMAGE="image",e.VIDEO="video"}(l||(l={})),function(e){e.OFFLINE="offline",e.LIVE="live"}(o||(o={}))},4752:(e,t,r)=>{"use strict";r.r(t),r.d(t,{default:()=>d,metadata:()=>c});var a=r(9510);r(7272);var s=r(8570);let i=(0,s.createProxy)(String.raw`/Users/charlpagne/Documents/aga/web-app/app/providers.tsx`),{__esModule:n,$$typeof:l}=i;i.default;let o=(0,s.createProxy)(String.raw`/Users/charlpagne/Documents/aga/web-app/app/providers.tsx#Providers`),c={title:"Africa Genius Alliance | Merit-Based Leadership Platform",description:"Africa Genius Alliance identifies, elevates, and supports Africa's most capable minds through transparency, ideas, and measurable impact.",keywords:"Africa, leadership, merit, transparency, genius, voting, impact",authors:[{name:"Africa Genius Alliance"}],openGraph:{title:"Africa Genius Alliance | Merit-Based Leadership Platform",description:"Leadership Earned by Merit. Not Politics.",type:"website",locale:"en_US",siteName:"Africa Genius Alliance"},twitter:{card:"summary_large_image",title:"Africa Genius Alliance",description:"Leadership Earned by Merit. Not Politics."}};function d({children:e}){return a.jsx("html",{lang:"en",children:a.jsx("body",{children:a.jsx(o,{children:e})})})}},7272:()=>{}};